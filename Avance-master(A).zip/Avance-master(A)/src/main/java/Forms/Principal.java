
package Forms;

import vista.LoginFrm;

public class Principal {
    public static void main(String[] args) {
        // Crea la vista de Login
        LoginFrm vista = new LoginFrm();
        vista.setVisible(true);
    }
}
