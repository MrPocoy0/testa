package vista;

import controlador.cProveedor;
import dao.ProveedorDao;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.sql.Connection;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import modelo.Proveedor;
import util.DataSource;
import java.awt.Desktop; // Para abrir el archivo automáticamente después de generarlo.
import java.io.File; // Para trabajar con archivos (crear/eliminar).
import java.io.FileOutputStream; // Para escribir datos en un archivo.
import java.io.IOException; // Para manejar excepciones relacionadas con la entrada/salida.
import javax.swing.JFileChooser; // Para abrir el diálogo de selección de archivos.
import javax.swing.filechooser.FileNameExtensionFilter; // Para aplicar filtros de tipo de archivo en el JFileChooser.
import javax.swing.JOptionPane; // Para mostrar mensajes al usuario.
import org.apache.poi.hssf.usermodel.HSSFWorkbook; // Para trabajar con archivos Excel en formato .xls.
import org.apache.poi.ss.usermodel.*; 

public class ListaProveedores extends javax.swing.JFrame {

    // Obtener la conexión a la base de datos
    Connection conexion = DataSource.obtenerConexion();

    // Crear instancia de ProveedorDao con la conexión
    ProveedorDao proveedorDao = new ProveedorDao(conexion);

    // Crear instancia del controlador con el DAO
    cProveedor controlador = new cProveedor(proveedorDao);

    DefaultTableModel modelo;

    public ListaProveedores() {
        initComponents();
        setLocationRelativeTo(null); // Centrar en pantalla al inicio.

        // Crear un panel envolvente con GridBagLayout para centrar el contenido.
        JPanel wrapperPanel = new JPanel();
        wrapperPanel.setLayout(new GridBagLayout()); // Centra automáticamente el contenido.
        wrapperPanel.setBackground(new Color(255, 204, 51)); // Color de fondo del panel envolvente.
        
        wrapperPanel.add(jPanel1); // Agregar el panel principal al envolvente.
        setContentPane(wrapperPanel); // Establecer el panel envolvente como el contenido principal.
        pack(); // Ajustar el tamaño de la ventana al contenido.

        modelo = (DefaultTableModel) tblProveedores.getModel();
        llenarTabla();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        btnAgregarProveedor = new javax.swing.JButton();
        cmbProveedores = new javax.swing.JComboBox<>();
        btnBuscarProveedores = new javax.swing.JButton();
        txtBuscar = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblProveedores = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnExportar3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 204, 51));
        jPanel1.setToolTipText("");

        jLabel8.setFont(new java.awt.Font("Gill Sans MT", 1, 16)); // NOI18N
        jLabel8.setText("LISTA DE PROVEEDORES");

        btnAgregarProveedor.setBackground(new java.awt.Color(204, 204, 0));
        btnAgregarProveedor.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        btnAgregarProveedor.setText("Agregar Proveedor");
        btnAgregarProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarProveedorActionPerformed(evt);
            }
        });

        cmbProveedores.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        cmbProveedores.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Filtrar Por" }));

        btnBuscarProveedores.setBackground(new java.awt.Color(0, 153, 204));
        btnBuscarProveedores.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        btnBuscarProveedores.setText("Buscar");
        btnBuscarProveedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarProveedoresActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Gill Sans MT", 1, 14)); // NOI18N
        jLabel7.setText("Buscar:");

        btnEditar.setBackground(new java.awt.Color(102, 204, 0));
        btnEditar.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(255, 102, 102));
        btnEliminar.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        tblProveedores.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        tblProveedores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nombre", "RUC", "Correo", "Teléfono", "Dirección", "País"
            }
        ));
        tblProveedores.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane4.setViewportView(tblProveedores);
        if (tblProveedores.getColumnModel().getColumnCount() > 0) {
            tblProveedores.getColumnModel().getColumn(0).setMinWidth(45);
            tblProveedores.getColumnModel().getColumn(0).setPreferredWidth(45);
            tblProveedores.getColumnModel().getColumn(0).setMaxWidth(45);
            tblProveedores.getColumnModel().getColumn(1).setMinWidth(135);
            tblProveedores.getColumnModel().getColumn(1).setPreferredWidth(135);
            tblProveedores.getColumnModel().getColumn(1).setMaxWidth(135);
            tblProveedores.getColumnModel().getColumn(2).setMinWidth(120);
            tblProveedores.getColumnModel().getColumn(2).setPreferredWidth(120);
            tblProveedores.getColumnModel().getColumn(2).setMaxWidth(120);
            tblProveedores.getColumnModel().getColumn(4).setMinWidth(110);
            tblProveedores.getColumnModel().getColumn(4).setPreferredWidth(110);
            tblProveedores.getColumnModel().getColumn(4).setMaxWidth(110);
            tblProveedores.getColumnModel().getColumn(6).setMinWidth(110);
            tblProveedores.getColumnModel().getColumn(6).setPreferredWidth(110);
            tblProveedores.getColumnModel().getColumn(6).setMaxWidth(110);
        }

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/proveedor.png"))); // NOI18N

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/editar.png"))); // NOI18N

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/eliminar.png"))); // NOI18N

        btnExportar3.setBackground(new java.awt.Color(0, 102, 51));
        btnExportar3.setText("Exportar Excel");
        btnExportar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportar3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(101, 101, 101)
                        .addComponent(btnAgregarProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(31, 31, 31)
                                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addComponent(btnBuscarProveedores, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(102, 102, 102)
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(44, 44, 44)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnExportar3)
                            .addComponent(cmbProveedores, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(70, 70, 70))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(12, 12, 12)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 853, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(13, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAgregarProveedor)
                            .addComponent(jLabel8))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnBuscarProveedores)
                                    .addComponent(cmbProveedores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 342, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnEditar)
                                .addComponent(btnEliminar))
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnExportar3, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(24, 24, 24))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(81, 81, 81)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(82, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarProveedorActionPerformed
        AgrProveedorFRM agrProveedor = new AgrProveedorFRM();
        this.dispose();
        agrProveedor.setVisible(true);
    }//GEN-LAST:event_btnAgregarProveedorActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
       MainFRM main=new MainFRM();
       main.setVisible(true);
    }//GEN-LAST:event_formWindowClosing

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
       int selectedRow=tblProveedores.getSelectedRow();
       
       if(selectedRow!=-1){
           int idProveedor=(int)modelo.getValueAt(selectedRow, 0);
           controlador.eliminarProveedor(idProveedor);
           modelo.removeRow(selectedRow);
           JOptionPane.showMessageDialog(null, "Proveedor eliminado exitosamente");
       }else{
           JOptionPane.showMessageDialog(this, "Seleccione un proveedor para eliminar.");
       }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        abrirVentanaEdicion();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnBuscarProveedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarProveedoresActionPerformed
        buscarProveedores();
    }//GEN-LAST:event_btnBuscarProveedoresActionPerformed

    private void btnExportar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportar3ActionPerformed
        JFileChooser chooser = new JFileChooser();
    FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de Excel", "xls");
    chooser.setFileFilter(filter);
    chooser.setDialogTitle("Guardar archivo");
    chooser.setAcceptAllFileFilterUsed(false);

    // Si el usuario confirma la selección
    if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
        String ruta = chooser.getSelectedFile().toString().concat(".xls"); // Añade la extensión .xls al archivo.
        try {
            // Crear un archivo Excel nuevo
            File archivoXLS = new File(ruta);
            if (archivoXLS.exists()) {
                archivoXLS.delete();
            }
            archivoXLS.createNewFile();
            Workbook libro = new HSSFWorkbook();
            FileOutputStream archivo = new FileOutputStream(archivoXLS);
            Sheet hoja = libro.createSheet("Proveedores");

            // Agregar encabezados desde la tabla
            Row encabezado = hoja.createRow(0);
            for (int col = 0; col < tblProveedores.getColumnCount(); col++) {
                Cell celda = encabezado.createCell(col);
                celda.setCellValue(tblProveedores.getColumnName(col));
            }

            // Agregar datos desde la tabla
            for (int filaTabla = 0; filaTabla < tblProveedores.getRowCount(); filaTabla++) {
                Row filaExcel = hoja.createRow(filaTabla + 1);
                for (int col = 0; col < tblProveedores.getColumnCount(); col++) {
                    Cell celda = filaExcel.createCell(col);
                    Object valor = tblProveedores.getValueAt(filaTabla, col);
                    if (valor != null) {
                        if (valor instanceof Number) {
                            celda.setCellValue(Double.parseDouble(valor.toString()));
                        } else {
                            celda.setCellValue(valor.toString());
                        }
                    }
                }
            }

            // Escribir en el archivo y cerrarlo
            libro.write(archivo);
            archivo.close();

            // Abrir el archivo automáticamente
            Desktop.getDesktop().open(archivoXLS);
            JOptionPane.showMessageDialog(this, "Archivo exportado correctamente a:\n" + ruta);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al exportar el archivo: " + e.getMessage());
        }
    }
    }//GEN-LAST:event_btnExportar3ActionPerformed

    private void llenarTabla() {

        // Obtener la lista de proveedores del controlador
        List<Proveedor> proveedores = controlador.listarProveedores();

        // Limpiar las filas existentes en la tabla
        modelo.setRowCount(0);

        // Agregar los proveedores al modelo de la tabla
        for (Proveedor p : proveedores) {
            modelo.addRow(new Object[]{
                p.getIdProveedor(),
                p.getNombre(),
                p.getRuc(),
                p.getCorreo(),
                p.getCelular(),
                p.getDireccion(),
                p.getPais()
            });
        }
    }
    
    // Método para abrir la ventana de edición con los datos del proveedor seleccionado
    private void abrirVentanaEdicion() {
        int filaSeleccionada = tblProveedores.getSelectedRow();
        if (filaSeleccionada != -1) {
            // Obtener los datos del proveedor seleccionado
            int id = (int) modelo.getValueAt(filaSeleccionada, 0);
            String nombre = (String) modelo.getValueAt(filaSeleccionada, 1);
            String ruc = (String) modelo.getValueAt(filaSeleccionada, 2);
            String correo = (String) modelo.getValueAt(filaSeleccionada, 3);
            String celular = (String) modelo.getValueAt(filaSeleccionada, 4);
            String direccion = (String) modelo.getValueAt(filaSeleccionada, 5);
            String pais = (String) modelo.getValueAt(filaSeleccionada, 6);

            // Crear el proveedor y abrir la ventana de edición
            Proveedor proveedor = new Proveedor(id, nombre, ruc, correo, celular, direccion, pais);
            EdicionProveedor ventanaEdicion = new EdicionProveedor(proveedor, this);
            ventanaEdicion.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un proveedor para editar.");
        }
    }

    // Método para actualizar la tabla después de editar un proveedor
    public void actualizarProveedorEnTabla(Proveedor proveedor) {
        for (int i = 0; i < modelo.getRowCount(); i++) {
            if ((int) modelo.getValueAt(i, 0) == proveedor.getIdProveedor()) {
                modelo.setValueAt(proveedor.getNombre(), i, 1);
                modelo.setValueAt(proveedor.getRuc(), i, 2);
                modelo.setValueAt(proveedor.getCorreo(), i, 3);
                modelo.setValueAt(proveedor.getCelular(), i, 4);
                modelo.setValueAt(proveedor.getDireccion(), i, 5);
                modelo.setValueAt(proveedor.getPais(), i, 6);
                break;
            }
        }
    }
    
    // Método para buscar y actualizar la tabla con los resultados
    private void buscarProveedores() {
        String nombre = txtBuscar.getText();
        List<Proveedor> proveedores = controlador.buscarProveedor(nombre);
        actualizarTabla(proveedores);
    }
    
    // Método para actualizar los datos en la tabla
    private void actualizarTabla(List<Proveedor> proveedores) {
        modelo.setRowCount(0);  // Limpiar la tabla
        for (Proveedor p : proveedores) {
            modelo.addRow(new Object[]{
                p.getIdProveedor(), p.getNombre(), p.getRuc(), p.getCorreo(),
                p.getCelular(), p.getDireccion(), p.getPais()
            });
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarProveedor;
    private javax.swing.JButton btnBuscarProveedores;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnExportar3;
    private javax.swing.JComboBox<String> cmbProveedores;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable tblProveedores;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
