package vista;

import controlador.cOrdenCompra;
import java.awt.Color;
import java.awt.GridBagLayout;
import modelo.OrdenCompra;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.awt.Desktop; // Para abrir el archivo automáticamente después de generarlo.
import java.io.File; // Para trabajar con archivos (crear/eliminar).
import java.io.FileOutputStream; // Para escribir datos en un archivo.
import java.io.IOException; // Para manejar excepciones relacionadas con la entrada/salida.
import javax.swing.JFileChooser; // Para abrir el diálogo de selección de archivos.
import javax.swing.filechooser.FileNameExtensionFilter; // Para aplicar filtros de tipo de archivo en el JFileChooser.
import javax.swing.JOptionPane; // Para mostrar mensajes al usuario.
import org.apache.poi.hssf.usermodel.HSSFWorkbook; // Para trabajar con archivos Excel en formato .xls.
import org.apache.poi.ss.usermodel.*; 

public class ListaPedidosFrm extends javax.swing.JFrame {

    private final cOrdenCompra controlador;
    private DefaultTableModel modelo;

    public ListaPedidosFrm() {
        initComponents();
        setLocationRelativeTo(null); // Centrar en pantalla al inicio.

        // Crear un panel envolvente con GridBagLayout para centrar el contenido.
        JPanel wrapperPanel = new JPanel();
        wrapperPanel.setLayout(new GridBagLayout()); // Centra automáticamente el contenido.
        wrapperPanel.setBackground(new Color(255, 204, 51)); // Color de fondo del panel envolvente.

        wrapperPanel.add(jPanel1); // Agregar el panel principal al envolvente.
        setContentPane(wrapperPanel); // Establecer el panel envolvente como el contenido principal.
        pack(); // Ajustar el tamaño de la ventana al contenido.

        controlador = new cOrdenCompra();
        modelo = (DefaultTableModel) tblPedidos.getModel();
        llenarTabla();
    }

    private void llenarTabla() {
        List<OrdenCompra> pedidos = controlador.obtenerOrdenesCompra();
        modelo.setRowCount(0); // Limpiar la tabla
        for (OrdenCompra pedido : pedidos) {
            modelo.addRow(new Object[]{
                pedido.getIdOrden(),
                pedido.getProducto().getIdProducto(),
                pedido.getProveedor().getIdProveedor(),
                pedido.getCantidad(),
                pedido.getPrecioCompra(),
                pedido.getFechaCompra()
            });
        }
    }

    private void buscarPedido(String nombre) {
        List<OrdenCompra> pedidos = controlador.buscarPedidos(nombre);
        modelo.setRowCount(0); // Limpiar la tabla
        for (OrdenCompra pedido : pedidos) {
            modelo.addRow(new Object[]{
                pedido.getIdOrden(),
                pedido.getProducto().getIdProducto(),
                pedido.getProveedor().getIdProveedor(),
                pedido.getCantidad(),
                pedido.getPrecioCompra(),
                pedido.getFechaCompra()
            });
        }
    }

    private void editarPedido(int idPedido, OrdenCompra nuevoPedido) {
        boolean exito = controlador.actualizarOrdenCompra(nuevoPedido);
        if (exito) {
            llenarTabla();
            JOptionPane.showMessageDialog(this, "Pedido editado con éxito");
        } else {
            JOptionPane.showMessageDialog(this, "Error al editar el pedido");
        }
    }

    private void eliminarPedido(int idPedido) {
        boolean exito = controlador.eliminarOrdenCompra(idPedido);
        if (exito) {
            llenarTabla();
            JOptionPane.showMessageDialog(this, "Pedido eliminado con éxito");
        } else {
            JOptionPane.showMessageDialog(this, "Error al eliminar el pedido");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtBuscarPedido = new javax.swing.JTextField();
        btnBuscarPedido = new javax.swing.JButton();
        cmbPedidos = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblPedidos = new javax.swing.JTable();
        btnEditarPedido = new javax.swing.JButton();
        btnEliminarPedido = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnAggPedido = new javax.swing.JButton();
        btnExportar2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 204, 51));

        jLabel6.setFont(new java.awt.Font("Gill Sans MT", 1, 14)); // NOI18N
        jLabel6.setText("Buscar:");

        btnBuscarPedido.setBackground(new java.awt.Color(0, 153, 204));
        btnBuscarPedido.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        btnBuscarPedido.setText("Buscar");
        btnBuscarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarPedidoActionPerformed(evt);
            }
        });

        cmbPedidos.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        cmbPedidos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Filtrar Por" }));

        jLabel5.setFont(new java.awt.Font("Gill Sans MT", 1, 16)); // NOI18N
        jLabel5.setText("LISTA DE PEDIDOS");

        tblPedidos.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        tblPedidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Producto", "Proveedor", "Cantidad", "Precio de compra", "Fecha de compra"
            }
        ));
        jScrollPane3.setViewportView(tblPedidos);
        if (tblPedidos.getColumnModel().getColumnCount() > 0) {
            tblPedidos.getColumnModel().getColumn(0).setMinWidth(45);
            tblPedidos.getColumnModel().getColumn(0).setPreferredWidth(45);
            tblPedidos.getColumnModel().getColumn(0).setMaxWidth(45);
            tblPedidos.getColumnModel().getColumn(3).setMinWidth(90);
            tblPedidos.getColumnModel().getColumn(3).setPreferredWidth(90);
            tblPedidos.getColumnModel().getColumn(3).setMaxWidth(90);
        }

        btnEditarPedido.setBackground(new java.awt.Color(102, 204, 0));
        btnEditarPedido.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        btnEditarPedido.setText("Editar");
        btnEditarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarPedidoActionPerformed(evt);
            }
        });

        btnEliminarPedido.setBackground(new java.awt.Color(255, 102, 102));
        btnEliminarPedido.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        btnEliminarPedido.setText("Eliminar");
        btnEliminarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarPedidoActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pedidos.png"))); // NOI18N

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/editar.png"))); // NOI18N

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/eliminar.png"))); // NOI18N

        btnAggPedido.setBackground(new java.awt.Color(204, 204, 0));
        btnAggPedido.setFont(new java.awt.Font("Gill Sans MT", 0, 16)); // NOI18N
        btnAggPedido.setText("Agregar Pedido");
        btnAggPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAggPedidoActionPerformed(evt);
            }
        });

        btnExportar2.setBackground(new java.awt.Color(0, 102, 51));
        btnExportar2.setText("Exportar Excel");
        btnExportar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportar2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(233, 233, 233)
                .addComponent(jLabel2)
                .addGap(264, 264, 264)
                .addComponent(jLabel3)
                .addGap(51, 51, 51)
                .addComponent(btnExportar2)
                .addContainerGap(152, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAggPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(89, 89, 89))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(28, 28, 28)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(242, 242, 242)
                            .addComponent(btnEditarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(40, 40, 40)
                            .addComponent(btnEliminarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(56, 56, 56)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel5)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addGap(17, 17, 17)
                                    .addComponent(txtBuscarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(29, 29, 29)
                            .addComponent(btnBuscarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(28, 28, 28)
                            .addComponent(cmbPedidos, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 811, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(29, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 369, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnAggPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(btnExportar2)
                                .addGap(8, 8, 8)))))
                .addGap(17, 17, 17))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(31, 31, 31)
                    .addComponent(jLabel5)
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtBuscarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6)
                        .addComponent(btnBuscarPedido)
                        .addComponent(cmbPedidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEditarPedido)
                        .addComponent(btnEliminarPedido))
                    .addGap(24, 24, 24)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEditarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarPedidoActionPerformed
        int selectedRow = tblPedidos.getSelectedRow();
        if (selectedRow != -1) {
            int idPedido = (int) modelo.getValueAt(selectedRow, 0);
            // Obtener los nuevos datos del pedido y crear un objeto OrdenCompra
            OrdenCompra nuevoPedido = new OrdenCompra();
            // Llenar nuevoPedido con los datos editados
            editarPedido(idPedido, nuevoPedido);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un pedido para editar");
        }

    }//GEN-LAST:event_btnEditarPedidoActionPerformed

    private void btnBuscarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarPedidoActionPerformed
        // TODO add your handling code here:
        buscarPedido(txtBuscarPedido.getText());


    }//GEN-LAST:event_btnBuscarPedidoActionPerformed

    private void btnEliminarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarPedidoActionPerformed
        // TODO add your handling code here:
        int selectedRow = tblPedidos.getSelectedRow();
        if (selectedRow != -1) {
            int idPedido = (int) modelo.getValueAt(selectedRow, 0);
            eliminarPedido(idPedido);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un pedido para eliminar");
        }

    }//GEN-LAST:event_btnEliminarPedidoActionPerformed

    private void btnAggPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAggPedidoActionPerformed
        // TODO add your handling code here:
        AgrPedido pedido = new AgrPedido();
        pedido.setVisible(true);
        this.dispose();


    }//GEN-LAST:event_btnAggPedidoActionPerformed

    private void btnExportar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportar2ActionPerformed
            // Usamos JFileChooser para elegir dónde guardar el archivo Excel.
    JFileChooser chooser = new JFileChooser();
    FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de Excel", "xls");
    chooser.setFileFilter(filter);
    chooser.setDialogTitle("Guardar archivo");
    chooser.setAcceptAllFileFilterUsed(false);

    // Si el usuario confirma la selección
    if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
        String ruta = chooser.getSelectedFile().toString().concat(".xls"); // Añade la extensión .xls al archivo.
        try {
            // Crear un archivo Excel nuevo
            File archivoXLS = new File(ruta);
            if (archivoXLS.exists()) {
                archivoXLS.delete();
            }
            archivoXLS.createNewFile();
            Workbook libro = new HSSFWorkbook();
            FileOutputStream archivo = new FileOutputStream(archivoXLS);
            Sheet hoja = libro.createSheet("Pedidos");

            // Agregar encabezados desde la tabla
            Row encabezado = hoja.createRow(0);
            for (int col = 0; col < tblPedidos.getColumnCount(); col++) {
                Cell celda = encabezado.createCell(col);
                celda.setCellValue(tblPedidos.getColumnName(col));
            }

            // Agregar datos desde la tabla
            for (int filaTabla = 0; filaTabla < tblPedidos.getRowCount(); filaTabla++) {
                Row filaExcel = hoja.createRow(filaTabla + 1);
                for (int col = 0; col < tblPedidos.getColumnCount(); col++) {
                    Cell celda = filaExcel.createCell(col);
                    Object valor = tblPedidos.getValueAt(filaTabla, col);
                    if (valor != null) {
                        if (valor instanceof Number) {
                            celda.setCellValue(Double.parseDouble(valor.toString()));
                        } else {
                            celda.setCellValue(valor.toString());
                        }
                    }
                }
            }

            // Escribir en el archivo y cerrarlo
            libro.write(archivo);
            archivo.close();

            // Abrir el archivo automáticamente
            Desktop.getDesktop().open(archivoXLS);
            JOptionPane.showMessageDialog(this, "Archivo exportado correctamente a:\n" + ruta);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al exportar el archivo: " + e.getMessage());
        }
    }
    }//GEN-LAST:event_btnExportar2ActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {
        MainFRM main = new MainFRM();
        main.setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAggPedido;
    private javax.swing.JButton btnBuscarPedido;
    private javax.swing.JButton btnEditarPedido;
    private javax.swing.JButton btnEliminarPedido;
    private javax.swing.JButton btnExportar2;
    private javax.swing.JComboBox<String> cmbPedidos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tblPedidos;
    private javax.swing.JTextField txtBuscarPedido;
    // End of variables declaration//GEN-END:variables
}
