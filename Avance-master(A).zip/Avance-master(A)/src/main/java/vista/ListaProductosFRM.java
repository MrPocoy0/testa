package vista;

import controlador.cProducto;
import java.awt.Color;
import java.awt.GridBagLayout;
import modelo.Producto;
import util.DataSource;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.awt.Desktop; // Para abrir el archivo automáticamente después de generarlo.
import java.io.File; // Para trabajar con archivos (crear/eliminar).
import java.io.FileOutputStream; // Para escribir datos en un archivo.
import java.io.IOException; // Para manejar excepciones relacionadas con la entrada/salida.
import javax.swing.JFileChooser; // Para abrir el diálogo de selección de archivos.
import javax.swing.filechooser.FileNameExtensionFilter; // Para aplicar filtros de tipo de archivo en el JFileChooser.
import javax.swing.JOptionPane; // Para mostrar mensajes al usuario.
import org.apache.poi.hssf.usermodel.HSSFWorkbook; // Para trabajar con archivos Excel en formato .xls.
import org.apache.poi.ss.usermodel.*; 

public class ListaProductosFRM extends javax.swing.JFrame {

    private final cProducto controlador;
    private DefaultTableModel modelo;

    public ListaProductosFRM() {
        initComponents();
        setLocationRelativeTo(null); // Centrar en pantalla al inicio.

        // Crear un panel envolvente con GridBagLayout para centrar el contenido.
        JPanel wrapperPanel = new JPanel();
        wrapperPanel.setLayout(new GridBagLayout()); // Centra automáticamente el contenido.
        wrapperPanel.setBackground(new Color(255, 204, 51)); // Color de fondo del panel envolvente.

        wrapperPanel.add(jPanel1); // Agregar el panel principal al envolvente.
        setContentPane(wrapperPanel); // Establecer el panel envolvente como el contenido principal.
        pack(); // Ajustar el tamaño de la ventana al contenido.
        
        controlador = new cProducto(DataSource.obtenerConexion());
        modelo = (DefaultTableModel) tblProductos.getModel();
        llenarTabla();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        cmbProductos = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblProductos = new javax.swing.JTable();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnExportar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 204, 51));

        jLabel3.setFont(new java.awt.Font("Gill Sans MT", 1, 16)); // NOI18N
        jLabel3.setText("LISTA DE PRODUCTOS");

        jLabel4.setFont(new java.awt.Font("Gill Sans MT", 1, 14)); // NOI18N
        jLabel4.setText("Buscar:");

        btnBuscar.setBackground(new java.awt.Color(0, 153, 204));
        btnBuscar.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        cmbProductos.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        cmbProductos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Filtrar Por" }));

        tblProductos.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        tblProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nombre", "Categoria", "Descripcion", "Stock", "Precio"
            }
        ));
        jScrollPane2.setViewportView(tblProductos);
        if (tblProductos.getColumnModel().getColumnCount() > 0) {
            tblProductos.getColumnModel().getColumn(0).setMinWidth(50);
            tblProductos.getColumnModel().getColumn(0).setPreferredWidth(50);
            tblProductos.getColumnModel().getColumn(0).setMaxWidth(50);
            tblProductos.getColumnModel().getColumn(2).setMinWidth(120);
            tblProductos.getColumnModel().getColumn(2).setPreferredWidth(120);
            tblProductos.getColumnModel().getColumn(2).setMaxWidth(120);
            tblProductos.getColumnModel().getColumn(3).setMinWidth(230);
            tblProductos.getColumnModel().getColumn(3).setPreferredWidth(230);
            tblProductos.getColumnModel().getColumn(3).setMaxWidth(230);
            tblProductos.getColumnModel().getColumn(4).setMinWidth(100);
            tblProductos.getColumnModel().getColumn(4).setPreferredWidth(100);
            tblProductos.getColumnModel().getColumn(4).setMaxWidth(100);
            tblProductos.getColumnModel().getColumn(5).setMinWidth(100);
            tblProductos.getColumnModel().getColumn(5).setPreferredWidth(100);
            tblProductos.getColumnModel().getColumn(5).setMaxWidth(100);
        }

        btnEditar.setBackground(new java.awt.Color(102, 204, 0));
        btnEditar.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(255, 102, 102));
        btnEliminar.setFont(new java.awt.Font("Gill Sans MT", 0, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnAgregar.setBackground(new java.awt.Color(204, 204, 0));
        btnAgregar.setFont(new java.awt.Font("Gill Sans MT", 0, 16)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/eliminar.png"))); // NOI18N

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/productos.png"))); // NOI18N

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/editar.png"))); // NOI18N

        btnExportar1.setBackground(new java.awt.Color(0, 153, 51));
        btnExportar1.setText("Exportar Excel");
        btnExportar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(238, 238, 238)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(248, 248, 248)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(btnExportar1)))
                .addContainerGap(138, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(29, 29, 29)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addGap(247, 247, 247)
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(27, 27, 27))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(21, 21, 21)
                            .addComponent(jLabel4)
                            .addGap(17, 17, 17)
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(36, 36, 36)
                            .addComponent(cmbProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 755, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(248, 248, 248)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(50, 50, 50)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(30, 30, 30)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnExportar1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 359, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel1))))
                .addGap(15, 15, 15))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(17, 17, 17)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel3)
                        .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4)
                        .addComponent(btnBuscar)
                        .addComponent(cmbProductos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 307, Short.MAX_VALUE)
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEditar)
                        .addComponent(btnEliminar))
                    .addGap(17, 17, 17)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        MainFRM main = new MainFRM();
        main.setVisible(true);
    }//GEN-LAST:event_formWindowClosing

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        AgrProductoFRM agrProducto = new AgrProductoFRM();
        this.dispose();
        agrProducto.setVisible(true);
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String nombre = txtBuscar.getText();
        List<Producto> productos = controlador.buscarProductosPorNombre(nombre);
        modelo.setRowCount(0); // Limpiar la tabla
        for (Producto producto : productos) {
            modelo.addRow(new Object[]{
                producto.getIdProducto(),
                producto.getNombre(),
                producto.getDescripcion(),
                producto.getCantidadStock(),
                producto.getPrecio()
            });
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int selectedRow = tblProductos.getSelectedRow();
        if (selectedRow != -1) { // Verifica si hay una fila seleccionada
            int idProducto = (int) modelo.getValueAt(selectedRow, 0); // Asumiendo que el ID está en la primera columna
            boolean resultado = controlador.eliminarProducto(idProducto); // Elimina el producto de la base de datos
            if (resultado) {
                modelo.removeRow(selectedRow); // Elimina la fila de la tabla
                JOptionPane.showMessageDialog(this, "Producto eliminado exitosamente.");
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar el producto.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un producto para eliminar.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnExportar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportar1ActionPerformed
        // Usamos JFileChooser para elegir dónde guardar el archivo Excel.
    JFileChooser chooser = new JFileChooser();
    FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de Excel", "xls");
    chooser.setFileFilter(filter);
    chooser.setDialogTitle("Guardar archivo");
    chooser.setAcceptAllFileFilterUsed(false);

    // Si el usuario confirma la selección
    if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
        String ruta = chooser.getSelectedFile().toString().concat(".xls"); // Añade la extensión .xls al archivo.
        try {
            // Crear un archivo Excel nuevo
            File archivoXLS = new File(ruta);
            if (archivoXLS.exists()) {
                archivoXLS.delete();
            }
            archivoXLS.createNewFile();
            Workbook libro = new HSSFWorkbook();
            FileOutputStream archivo = new FileOutputStream(archivoXLS);
            Sheet hoja = libro.createSheet("Productos");

            // Agregar encabezados desde la tabla
            Row encabezado = hoja.createRow(0);
            for (int col = 0; col < tblProductos.getColumnCount(); col++) {
                Cell celda = encabezado.createCell(col);
                celda.setCellValue(tblProductos.getColumnName(col));
            }

            // Agregar datos desde la tabla
            for (int filaTabla = 0; filaTabla < tblProductos.getRowCount(); filaTabla++) {
                Row filaExcel = hoja.createRow(filaTabla + 1);
                for (int col = 0; col < tblProductos.getColumnCount(); col++) {
                    Cell celda = filaExcel.createCell(col);
                    Object valor = tblProductos.getValueAt(filaTabla, col);
                    if (valor != null) {
                        if (valor instanceof Number) {
                            celda.setCellValue(Double.parseDouble(valor.toString()));
                        } else {
                            celda.setCellValue(valor.toString());
                        }
                    }
                }
            }

            // Escribir en el archivo y cerrarlo
            libro.write(archivo);
            archivo.close();

            // Abrir el archivo automáticamente
            Desktop.getDesktop().open(archivoXLS);
            JOptionPane.showMessageDialog(this, "Archivo exportado correctamente a:\n" + ruta);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al exportar el archivo: " + e.getMessage());
        }
    }// TODO add your handling code here:
    }//GEN-LAST:event_btnExportar1ActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {
            int selectedRow = tblProductos.getSelectedRow();
            if (selectedRow != -1) {
                int idProducto = (int) modelo.getValueAt(selectedRow, 0);
                Producto producto = controlador.obtenerProducto(idProducto); // Obtener el producto por ID
                AgrProductoFRM editarProducto = new AgrProductoFRM(producto);
                this.dispose();
                editarProducto.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione un producto para editar.");
            }
    }

    public void llenarTabla() {
        // Obtener la lista de productos del controlador
        List<Producto> productos = controlador.obtenerProductos();
        modelo.setRowCount(0); // Limpiar la tabla
        for (Producto producto : productos) {
            modelo.addRow(new Object[]{
                producto.getIdProducto(),
                producto.getNombre(),
                producto.getCategoria().getNombreCategoria(), // Asegúrate de obtener el nombre de la categoría
                producto.getDescripcion(), // Agregar la descripción del producto
                producto.getCantidadStock(),
                producto.getPrecio()
            });
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnExportar1;
    private javax.swing.JComboBox<String> cmbProductos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblProductos;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
